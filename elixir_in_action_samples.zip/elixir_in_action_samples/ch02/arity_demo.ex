defmodule Rectangle do
  def area(a), do: area(a, a)
  def area(a, b), do: a * b
end