defmodule Geometry do
  def rectangle_area(a, b) do
    a * b
  end
end