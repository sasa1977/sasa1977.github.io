defmodule Todo.ProcessRegistry do
  def start_link do
    IO.puts "Starting process registry"
    GenServer.start_link(__MODULE__, nil, name: :process_registry)
  end

  def register(key), do: register(self, key)

  def register(pid, key) do
    GenServer.call(:process_registry, {:register, pid, key})
  end

  def whereis(key) do
    GenServer.call(:process_registry, {:whereis, key})
  end

  def call(key, message) do
    with_pid(key, &GenServer.call(&1, message))
  end

  def cast(key, message) do
    with_pid(key, &GenServer.cast(&1, message))
  end

  defp with_pid(key, fun) do
    case whereis(key) do
      nil -> raise("no process registered under an alias #{inspect key}")
      pid -> fun.(pid)
    end
  end

  def init(_) do
    {:ok, HashDict.new}
  end

  def handle_call({:register, pid, key}, _, process_registry) do
    if Dict.has_key?(process_registry, key) do
      {:reply, {:error, :already_registered}, process_registry}
    else
      Process.monitor(pid)
      {:reply, :ok, Dict.put(process_registry, key, pid)}
    end
  end

  def handle_call({:whereis, key}, _, process_registry) do
    {:reply, process_registry[key], process_registry}
  end


  def handle_info({:DOWN, _, :process, pid, _}, process_registry) do
    new_registry =
      for {k, v} <- process_registry, v != pid, into: HashDict.new do
        {k, v}
      end
    {:noreply, new_registry}
  end

  def handle_info(_, state), do: {:noreply, state}
end