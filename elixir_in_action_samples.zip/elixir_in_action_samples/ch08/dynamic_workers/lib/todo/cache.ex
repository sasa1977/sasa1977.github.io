defmodule Todo.Cache do
  def start_link do
    Todo.ServerSupervisor.start_link
  end

  def get_or_create(todo_list_name) do
    case Todo.Server.whereis(todo_list_name) do
      :undefined ->
        {:ok, pid} = Todo.ServerSupervisor.start_child(todo_list_name)
        pid

      pid -> pid
    end
  end
end
