use Mix.Config

config :todo, port: 5454