defmodule Todo.Server do
  use GenServer

  def start_link(name) do
    IO.puts "Starting to-do server for #{name}"
    GenServer.start_link(Todo.Server, name, name: via_tuple(name))
  end

  def add_entry(todo_server, new_entry) do
    GenServer.call(todo_server, {:add_entry, new_entry})
  end

  def entries(todo_server, date) do
    GenServer.call(todo_server, {:entries, date})
  end


  def whereis(name) do
    :gproc.whereis_name({:n, :l, {:todo_server, name}})
  end

  defp via_tuple(name) do
    {:via, :gproc, {:n, :l, {:todo_server, name}}}
  end

  def init(name) do
    {:ok, {name, Todo.List.new}}
  end


  def handle_call({:add_entry, new_entry}, _, {name, todo_list}) do
    new_list = Todo.List.add_entry(todo_list, new_entry)
    Todo.Database.store({name, new_entry.date}, Todo.List.entries(new_list, new_entry.date))
    {:reply, :ok, {name, new_list}}
  end


  def handle_call({:entries, date}, _, {name, todo_list}) do
    {entries, todo_list} = case Todo.List.entries(todo_list, date) do
      nil ->
        entries = Todo.Database.get({name, date}) || []
        {
          entries,
          Todo.List.set_entries(todo_list, date, entries)
        }
      found -> {found, todo_list}
    end

    {:reply, entries, {name, todo_list}}
  end

  # Needed for testing purposes
  def handle_info(:stop, state), do: {:stop, :normal, state}
  def handle_info(_, state), do: {:noreply, state}
end