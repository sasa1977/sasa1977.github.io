defmodule Todo.DatabaseWorker do
  use GenServer

  def start_link(worker_id) do
    IO.puts "Starting database worker #{worker_id}"

    GenServer.start_link(
      __MODULE__, nil,
      name: via_tuple(worker_id)
    )
  end

  def store(worker_id, key, data) do
    GenServer.call(via_tuple(worker_id), {:store, key, data})
  end

  def get(worker_id, key) do
    GenServer.call(via_tuple(worker_id), {:get, key})
  end

  defp via_tuple(worker_id) do
    {:via, :gproc, {:n, :l, {:database_worker, worker_id}}}
  end


  def init(_) do
    {:ok, %{store_job: nil, queue: HashDict.new}}
  end


  def handle_call({:store, key, data}, from, state) do
    {:noreply, maybe_store(queue_request(state, from, key, data))}
  end

  def handle_call({:get, key}, _, state) do
    result = :mnesia.transaction(fn ->
      :mnesia.read({:todo_lists, key})
    end)

    data = case result do
      {:atomic, [{:todo_lists, ^key, list}]} -> list
      _ -> nil
    end

    {:reply, data, state}
  end


  def handle_info(:data_stored, state) do
    {:noreply, maybe_store(%{state | store_job: nil})}
  end

  # Needed for testing purposes
  def handle_info(:stop, state), do: {:stop, :normal, state}
  def handle_info(_, state), do: {:noreply, state}


  defp queue_request(state, from, key, data) do
    %{state | queue: HashDict.put(state.queue, key, {from, data})}
  end

  defp maybe_store(%{store_job: nil} = state) do
    if HashDict.size(state.queue) > 0 do
      worker = self
      %{state |
        queue: HashDict.new,
        store_job: spawn_link(fn -> do_write(worker, state.queue) end)
      }
    else
      state
    end
  end

  defp maybe_store(state), do: state

  defp do_write(worker, queue) do
    {:atomic, :ok} = :mnesia.transaction(fn ->
      for {key, {_, data}} <- queue, do: :ok = :mnesia.write({:todo_lists, key, data})
      :ok
    end)

    for {_, {from, _}} <- queue, do: GenServer.reply(from, :ok)

    send(worker, :data_stored)
  end
end