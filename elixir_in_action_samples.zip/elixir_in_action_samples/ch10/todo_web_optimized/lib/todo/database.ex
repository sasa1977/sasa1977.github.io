defmodule Todo.Database do
  @pool_size 3

  def start_link do
    :mnesia.stop
    :mnesia.create_schema([node()])
    :mnesia.start
    :mnesia.create_table(:todo_lists, [attributes: [:name, :list], disc_only_copies: [node()]])
    :ok = :mnesia.wait_for_tables([:todo_lists], 5000)

    Todo.PoolSupervisor.start_link(@pool_size)
  end

  def store(key, data) do
    Todo.DatabaseWorker.store(choose_worker(key), key, data)
  end

  def get(key) do
    Todo.DatabaseWorker.get(choose_worker(key), key)
  end

  def choose_worker(key) do
    (key |> :erlang.phash2 |> rem(@pool_size)) + 1
  end
end