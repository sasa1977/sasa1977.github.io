defmodule DatabaseServerTest do
  use ExUnit.Case, async: false

  setup do
    :meck.new(DatabaseWorker, [])
    :meck.expect(DatabaseWorker, :start, &MockDatabaseWorker.start/1)
    :meck.expect(DatabaseWorker, :store, &MockDatabaseWorker.store/3)
    :meck.expect(DatabaseWorker, :get, &MockDatabaseWorker.get/2)
    DatabaseServer.start("./test_persist")
    :ok
  end

  teardown do
    File.rm_rf("./test_persist/")
    send(:database_server, :stop)
    :meck.unload(DatabaseWorker)
  end

  test "pooling" do
    assert(DatabaseServer.store(1, :a) == DatabaseServer.store(1, :a))
    assert(DatabaseServer.get(1) == DatabaseServer.store(1, :a))
    assert(DatabaseServer.store(2, :a) != DatabaseServer.store(1, :a))
  end
end

defmodule MockDatabaseWorker do
  use GenServer.Behaviour

  def start(_) do
    :gen_server.start(__MODULE__, nil, [])
  end

  def store(worker_pid, key, data) do
    :gen_server.call(worker_pid, {:store, key, data})
  end

  def get(worker_pid, key) do
    :gen_server.call(worker_pid, {:get, key})
  end


  def init(state) do
    {:ok, state}
  end

  def handle_call({:store, _, _}, _, state) do
    {:reply, self, state}
  end

  def handle_call({:get, _}, _, state) do
    {:reply, self, state}
  end

  # Needed for testing purposes
  def handle_info(:stop, state), do: {:stop, :normal, state}
  def handle_info(_, state), do: {:noreply, state}
end