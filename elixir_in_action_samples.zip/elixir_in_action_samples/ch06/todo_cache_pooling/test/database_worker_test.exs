defmodule DatabaseWorkerTest do
  use ExUnit.Case, async: false

  setup do
    {:ok, worker} = DatabaseWorker.start("./test_persist")
    {:ok, worker: worker}
  end

  teardown context do
    File.rm_rf("./test_persist/")
    send(context[:worker], :stop)
  end

  test "get and store", context do
    assert(nil == DatabaseWorker.get(context[:worker], 1))

    DatabaseWorker.store(context[:worker], 1, {:some, "data"})
    DatabaseWorker.store(context[:worker], 2, {:another, ["data"]})

    assert({:some, "data"} == DatabaseWorker.get(context[:worker], 1))
    assert({:another, ["data"]} == DatabaseWorker.get(context[:worker], 2))
  end
end