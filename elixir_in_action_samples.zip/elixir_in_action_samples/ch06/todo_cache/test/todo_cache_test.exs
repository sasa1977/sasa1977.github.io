defmodule TodoCacheTest do
  use ExUnit.Case, async: true

  test "get_or_create" do
    {:ok, cache} = TodoCache.start
    bobs_list = TodoCache.get_or_create(cache, "bobs_list")
    alices_list = TodoCache.get_or_create(cache, "alices_list")

    assert(bobs_list != alices_list)
    assert(bobs_list == TodoCache.get_or_create(cache, "bobs_list"))
  end
end