defmodule TodoCacheTest do
  use ExUnit.Case, async: true

  test "get_or_create" do
    {:ok, cache} = Todo.Cache.start
    bobs_list = Todo.Cache.get_or_create(cache, "bobs_list")
    alices_list = Todo.Cache.get_or_create(cache, "alices_list")

    assert(bobs_list != alices_list)
    assert(bobs_list == Todo.Cache.get_or_create(cache, "bobs_list"))
  end
end