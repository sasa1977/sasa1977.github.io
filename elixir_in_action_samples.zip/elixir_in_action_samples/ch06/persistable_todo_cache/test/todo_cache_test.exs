defmodule TodoCacheTest do
  use ExUnit.Case, async: false

  setup do
    :meck.new(Todo.Database, [:no_link])
    :meck.expect(Todo.Database, :start, fn(_) -> nil end)
    :meck.expect(Todo.Database, :get, fn(_) -> nil end)
    :meck.expect(Todo.Database, :store, fn(_, _) -> :ok end)
    on_exit(fn -> :meck.unload(Todo.Database) end)
  end

  test "get_or_create" do
    {:ok, cache} = Todo.Cache.start
    bobs_list = Todo.Cache.get_or_create(cache, "bobs_list")
    alices_list = Todo.Cache.get_or_create(cache, "alices_list")

    assert(bobs_list != alices_list)
    assert(bobs_list == Todo.Cache.get_or_create(cache, "bobs_list"))

    send(cache, :stop)
  end
end