defmodule TodoCache.Mixfile do
  use Mix.Project

  def project do
    [ app: :todo_cache,
      version: "0.0.1",
      elixir: "~> 0.13.0",
      deps: deps(Mix.env)
    ]
  end

  def application do
    []
  end

  defp deps(:test) do
    [{:meck, github: "eproxus/meck"}]
  end

  defp deps(_) do
    []
  end
end