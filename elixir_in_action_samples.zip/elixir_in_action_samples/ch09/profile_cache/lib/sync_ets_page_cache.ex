defmodule SyncEtsPageCache do
  use GenServer

  def start_link do
    GenServer.start_link(__MODULE__, [], name: :sync_ets_page_cache)
  end

  def cached(key, fun) do
    GenServer.call(:sync_ets_page_cache, {:cached, key, fun})
  end

  def init(_) do
    {:ok, :ets.new(:sync_ets_page_cache, [:private])}
  end

  def handle_call({:cached, key, fun}, _, ets) do
    {:reply, get_or_cache(ets, key, fun), ets}
  end

  defp get_or_cache(ets, key, fun) do
    case :ets.lookup(ets, key) do
      [{^key, cached}] -> cached
      _ ->
        response = fun.()
        :ets.insert(ets, {key, response})
        response
    end
  end
end