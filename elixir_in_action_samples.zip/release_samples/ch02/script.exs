defmodule MyModule do
  def run do
    IO.puts "Called MyModule.run"
  end
end

MyModule.run