defmodule TodoCacheTest do
  use ExUnit.Case, async: false

  setup do
    :meck.new(DatabaseServer, [])
    :meck.expect(DatabaseServer, :start, fn(_) -> nil end)
    :meck.expect(DatabaseServer, :get, fn(_) -> nil end)
    :meck.expect(DatabaseServer, :store, fn(_, _) -> :ok end)
  end

  teardown do
    :meck.unload(DatabaseServer)
  end

  test "get_or_create" do
    {:ok, cache} = TodoCache.start
    bobs_list = TodoCache.get_or_create(cache, "bobs_list")
    alices_list = TodoCache.get_or_create(cache, "alices_list")

    assert(bobs_list != alices_list)
    assert(bobs_list == TodoCache.get_or_create(cache, "bobs_list"))

    send(cache, :stop)
  end
end