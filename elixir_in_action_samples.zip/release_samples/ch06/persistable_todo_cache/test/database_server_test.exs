defmodule DatabaseServerTest do
  use ExUnit.Case, async: false

  setup do
    DatabaseServer.start("./test_persist")
    :ok
  end

  teardown do
    File.rm_rf("./test_persist/")
    send(:database_server, :stop)
  end

  test "get and store" do
    assert(nil == DatabaseServer.get(1))

    DatabaseServer.store(1, {:some, "data"})
    DatabaseServer.store(2, {:another, ["data"]})

    assert({:some, "data"} == DatabaseServer.get(1))
    assert({:another, ["data"]} == DatabaseServer.get(2))
  end
end